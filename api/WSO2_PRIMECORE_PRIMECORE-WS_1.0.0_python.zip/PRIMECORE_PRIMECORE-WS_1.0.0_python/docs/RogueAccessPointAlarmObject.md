# RogueAccessPointAlarmObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | [optional] 
**acknowledgement_status** | **bool** |  | [optional] 
**alarm_found_at** | **str** |  | [optional] 
**device_name** | **str** |  | [optional] 
**last_updated_at** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**severity** | **str** |  | [optional] 
**time_stamp** | **str** |  | [optional] 
**wireless_specific_alarm_id** | **str** |  | [optional] 
**rogue_ap_alarm_details** | [**RogueAccessPointAlarmObjectRogueApAlarmDetails**](RogueAccessPointAlarmObjectRogueApAlarmDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


