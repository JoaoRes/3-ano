# RogueAccessPointAlarmObjectRogueApAlarmDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**classification_type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**rogue_clients** | **float** |  | [optional] 
**rssi** | **float** |  | [optional] 
**ssid** | **str** |  | [optional] 
**state** | **str** |  | [optional] 
**mac_address** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


