# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first** | **float** |  | [optional] 
**last** | **float** |  | [optional] 
**count** | **float** |  | [optional] 
**access_points** | [**list[RogueAccessPointAlarmObject]**](RogueAccessPointAlarmObject.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


