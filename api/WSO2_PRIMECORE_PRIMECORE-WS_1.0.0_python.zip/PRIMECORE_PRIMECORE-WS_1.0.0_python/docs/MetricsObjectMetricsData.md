# MetricsObjectMetricsData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_date_time** | **float** |  | [optional] 
**metric_name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**values** | [**list[MetricsObjectMetricsDataValues]**](MetricsObjectMetricsDataValues.md) |  | [optional] 
**x_value_property** | [**MetricsObjectMetricsDataXValueProperty**](MetricsObjectMetricsDataXValueProperty.md) |  | [optional] 
**y_value_property** | [**MetricsObjectMetricsDataYValueProperty**](MetricsObjectMetricsDataYValueProperty.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


