# AccessPointObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | [optional] 
**client_count** | **float** |  | [optional] 
**client_count_2_4_g_hz** | **float** |  | [optional] 
**client_count_5_g_hz** | **float** |  | [optional] 
**location** | **str** |  | [optional] 
**model** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**up_time** | **float** |  | [optional] 
**mac_address** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


